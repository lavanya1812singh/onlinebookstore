Rails.application.routes.draw do
  root 'books#index'
  resources :books
  resources :genres
  resources :users do
  resources :carts
  end
  resources :ratings
  get 'carts', to: 'carts#index'
  get 'carts/new', to: 'carts#new', as: 'new_cart'
  get 'carts/:id', to: 'carts#show', as: 'cart'
  get 'carts/:id/edit', to: 'carts#edit', as: 'edit_cart'
  post 'carts', to: 'carts#create'
  patch 'carts/:id', to: 'carts#update'
  delete 'carts/:id', to: 'carts#destroy'
end
