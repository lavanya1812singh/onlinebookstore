class Book < ApplicationRecord
  has_many :line_items
  has_many :carts, through: :line_items
  has_many :ratings
  has_and_belongs_to_many :genres
  validates :title, presence: true
  validates :author, presence: true
end
