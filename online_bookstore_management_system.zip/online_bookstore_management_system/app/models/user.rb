
class User < ApplicationRecord
  has_secure_password
  has_many :carts, dependent: :destroy
  has_many :ratings

  validates :email, presence: true, uniqueness: true


  def self.authenticate(email, password)
    user = find_by(email: email)
    return user if user && user.authenticate(password)
  end
end
